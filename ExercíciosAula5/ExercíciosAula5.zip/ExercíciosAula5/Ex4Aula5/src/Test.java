public class Test {
    private int a;
    public Test (int a) {
        this.a = a;
    }
    public void setA(int a) {
        this.a = a;
    }
    public int getA() {
        return a;
    }
}